package com.niharika.android.groupexpensetracker;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.NavigationUI;

import static androidx.navigation.fragment.NavHostFragment.findNavController;


/**
 * A simple {@link Fragment} subclass.
 */
public class AddAccountFragment extends Fragment {

    private TextView mAccountName;
    private TextView mDescription;
    private CheckBox mDefaultAccount;
    private TextView mInitialBalance;
    private Button mOkButton, mCancelButton,mDeleteButton;
    private Account mAccount;
    private Spinner mCurrencySpinner;


    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        inflater.inflate(R.menu.fragment_add_account, menu);
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        saveAccountDetails();
        NavController navController = findNavController(this);
        return NavigationUI.onNavDestinationSelected(item, navController) || super.onOptionsItemSelected(item);
    }




    @Override
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        mAccount=new Account();
        setHasOptionsMenu(true);

    }

    void saveAccountDetails(){
        mAccount.setAccName(mAccountName.getText().toString());
        mAccount.setDescription(mDescription.getText().toString());
        mAccount.setDefault(mDefaultAccount.isChecked());
        mAccount.setCurrency(mCurrencySpinner.getSelectedItem().toString());
        AccountLab.get(getActivity()).addAccount(mAccount);

    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view=inflater.inflate(R.layout.fragment_add_account, container, false);
        mOkButton=(Button)view.findViewById(R.id.ok_button);
        mCancelButton=(Button)view.findViewById(R.id.cancel_button);
        mAccountName=(TextView)view.findViewById(R.id.account_name);
        mDescription=(TextView)view.findViewById(R.id.account_description);
        mInitialBalance=(TextView)view.findViewById(R.id.initial_balance);
        mDefaultAccount=(CheckBox) view.findViewById(R.id.default_checkbox);
        mOkButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                saveAccountDetails();
                Navigation.findNavController(view).navigate(R.id.action_addAccountFragment_to_accountTabFragment);
            }
        });
        mCancelButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Navigation.findNavController(view).navigate(R.id.action_addAccountFragment_to_accountTabFragment);

            }
        });
        mCurrencySpinner = (Spinner) view.findViewById(R.id.spinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(getActivity(),
                R.array.currency_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mCurrencySpinner.setAdapter(adapter);
        mCurrencySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                //mAccount.setCurrency(parent.getItemAtPosition(pos).toString());

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        return view;
    }
}

