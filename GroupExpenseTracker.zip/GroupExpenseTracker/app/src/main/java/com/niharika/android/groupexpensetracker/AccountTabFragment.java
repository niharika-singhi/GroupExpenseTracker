package com.niharika.android.groupexpensetracker;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TableLayout;

import java.util.List;

import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.NavigationUI;

import static androidx.navigation.fragment.NavHostFragment.findNavController;

public class AccountTabFragment extends Fragment {

    private TabLayout mAccountTab;
    private List<Account> mAccounts;
    private ViewPager mViewPager;
    Account account;

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        inflater.inflate(R.menu.fragment_account_tab, menu);

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        NavController navController = findNavController(this);
        return NavigationUI.onNavDestinationSelected(item,navController) || super.onOptionsItemSelected(item);
        //NavigationUI.onNavDestinationSelected(item,
          //      findNavController(this))
            //    || super.onOptionsItemSelected(item);

       /* switch (item.getItemId()) {
            case R.id.menu_item_account_list:
                //showAccountList();
                //updateUI();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }*/
    }

        /*void showAccountList(){
            Fragment accountList=AccountListFragment.newInstance();
            getFragmentManager().beginTransaction()
                    .replace(R.id.fragment_container, accountList)
                    .commit();
        }
*/


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mAccounts = AccountLab.get(getActivity()).getAccounts();
        setHasOptionsMenu(true);


    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_account_tab, container, false);
        mAccountTab = (TabLayout) v.findViewById(R.id.account_tab_layout);


        FragmentManager fragmentManager = getFragmentManager();
        mViewPager = (ViewPager) v.findViewById(R.id.account_tab_view_pager);
        mAccountTab.setupWithViewPager(mViewPager);
        mViewPager.setAdapter(new FragmentStatePagerAdapter(fragmentManager) {

            @Override
            public Fragment getItem(int position) {
                account = mAccounts.get(position);
                return AccountFragment.newInstance(account.getAccNo());
            }

            @Override
            public String getPageTitle(int position) {
                account = mAccounts.get(position);
                return account.getAccName();
            }

            @Override
            public int getCount() {
                return mAccounts.size();
            }

        });

        return v;
    }


}
