package com.niharika.android.groupexpensetracker;


import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v7.app.ActionBar;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import java.util.UUID;

import androidx.navigation.Navigation;


public class AccountListFragment extends Fragment {

    //This will have a recycler view or list view and a add account button

    private FloatingActionButton mAddAccountButton;

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        inflater.inflate(R.menu.fragment_account_list, menu);
        setFragmentTitle();
    }

    public void setFragmentTitle(){
        getActivity().setTitle(R.string.account_list_fragment_title);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.fragment_account_list, container, false);
        setHasOptionsMenu(true);
        mAddAccountButton=(FloatingActionButton)view.findViewById(R.id.add_account_button);
        mAddAccountButton.setOnClickListener(
                Navigation.createNavigateOnClickListener(
                        R.id.action_accountListFragment_to_addAccountFragment));
        return view;
    }
}
