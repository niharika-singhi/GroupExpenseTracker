package com.niharika.android.groupexpensetracker;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Created by niharika on 3/13/2019.
 */

public class AccountLab {
    private static AccountLab sAccountLab;
    private Context mContext;
    private SQLiteDatabase mDatabase;
    List mAccounts;

    private AccountLab(Context context) {
        mContext = context.getApplicationContext();
        mAccounts = new ArrayList<>();
    }

    public static AccountLab get(Context context) {
        if (sAccountLab == null)
            sAccountLab = new AccountLab(context);
        return sAccountLab;
    }

    public void addAccount(Account account){
        mAccounts.add(account);

    }

    public void addAccount(String name,String desc,String initialBalance,String defaultAccount){
        Account account=new Account();
        account.setAccName(name);
        account.setDescription(desc);
        account.setDefault(Boolean.parseBoolean(defaultAccount));
        mAccounts.add(account);

    }

    public List<Account> getAccounts() {
        return mAccounts;
    }

    public Account getAccount(UUID ano) {

        Account account;
        for (int i = 0; i < mAccounts.size(); i++) {
            account = (Account) mAccounts.get(i);
            if (account.getAccNo().equals(ano))
                return account;
        }
        return null;
    }
}
