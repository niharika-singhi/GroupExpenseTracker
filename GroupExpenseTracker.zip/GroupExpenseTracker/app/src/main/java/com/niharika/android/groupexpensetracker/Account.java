package com.niharika.android.groupexpensetracker;

import java.util.Date;
import java.util.UUID;

/**
 * Created by niharika on 3/13/2019.
 */

public class Account {

    public UUID getAccNo() {
        return mAccNo;
    }

    public void setAccNo(UUID accNo) {
        mAccNo = accNo;
    }

    private UUID mAccNo;
    private String mAccName;
    private String mDescription;
    private boolean mDefaultAccount;
    private Date mDate;

    public String getCurrency() {
        return mCurrency;
    }

    public void setCurrency(String currency) {
        mCurrency = currency;
    }

    private String mCurrency;
    // private <ArrayList>Transaction mTransactionList;
    //private <ArrayList>Member mMembersList;

    public Account() {
        this(UUID.randomUUID());
    }
    public Account(UUID id) {
        mAccNo=id;
        mDate=new Date();
    }
    public Account(String name,String desc,String initialBalance,String defaultAccount) {
        this(UUID.randomUUID());
        mAccName=name;
        mDescription=desc;
        mDefaultAccount= Boolean.parseBoolean(defaultAccount);
    }

    public String getDescription() {
        return mDescription;
    }

    public void setDescription(String description) {
        mDescription = description;
    }

    public boolean isDefault() {
        return mDefaultAccount;
    }

    public void setDefault(boolean defaultAccount) {
        mDefaultAccount = defaultAccount;
    }

    public String getAccName() {
        return mAccName;
    }

    public void setAccName(String accName) {
        mAccName = accName;
    }





}

